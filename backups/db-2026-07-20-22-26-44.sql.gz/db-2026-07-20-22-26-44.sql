--
-- PostgreSQL database dump
--

\restrict oUvultnCINWsODgECJlEeQvWHihJpikaKp9Idez8jmSaZptFj580ro3rXYb7TsF

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: submissionstatus; Type: TYPE; Schema: public; Owner: 1702admin
--

CREATE TYPE public.submissionstatus AS ENUM (
    'REVIEWED',
    'PENDING',
    'OK',
    'COMPILATION_ERROR',
    'RUNTIME_ERROR',
    'TIME_LIMIT',
    'WALL_TIME_LIMIT',
    'MEMORY_LIMIT',
    'WRONG_ANSWER',
    'PRESENTATION_ERROR',
    'CHECK_FAILED',
    'PARTIAL_SOLUTION',
    'SECURITY_VIOLATION',
    'PENDING_CHECK',
    'PENDING_REVIEW',
    'ACCEPTED_TESTING',
    'IGNORED',
    'DISQUALIFIED',
    'REJECTED',
    'SUMMONED_DEFENCE',
    'STYLE_VIOLATION',
    'NO_CHANGE',
    'REJUDGE',
    'FULL_REJUDGE'
);


ALTER TYPE public.submissionstatus OWNER TO "1702admin";

--
-- Name: usertype; Type: TYPE; Schema: public; Owner: 1702admin
--

CREATE TYPE public.usertype AS ENUM (
    'ADMIN',
    'STUDENT',
    'TEACHER',
    'BANNED'
);


ALTER TYPE public.usertype OWNER TO "1702admin";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: 1702admin
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO "1702admin";

--
-- Name: submission_review; Type: TABLE; Schema: public; Owner: 1702admin
--

CREATE TABLE public.submission_review (
    id bigint NOT NULL,
    submission_id bigint NOT NULL,
    teacher_id bigint NOT NULL,
    reviewed_at timestamp without time zone NOT NULL,
    comment text
);


ALTER TABLE public.submission_review OWNER TO "1702admin";

--
-- Name: submission_review_id_seq; Type: SEQUENCE; Schema: public; Owner: 1702admin
--

CREATE SEQUENCE public.submission_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submission_review_id_seq OWNER TO "1702admin";

--
-- Name: submission_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: 1702admin
--

ALTER SEQUENCE public.submission_review_id_seq OWNED BY public.submission_review.id;


--
-- Name: submissions; Type: TABLE; Schema: public; Owner: 1702admin
--

CREATE TABLE public.submissions (
    submission_id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    code text NOT NULL,
    status public.submissionstatus NOT NULL,
    passed_tests integer NOT NULL,
    total_tests integer NOT NULL,
    error_message text,
    comment text,
    submitted_at timestamp with time zone NOT NULL,
    celery_task_id character varying(64) NOT NULL
);


ALTER TABLE public.submissions OWNER TO "1702admin";

--
-- Name: submissions_submission_id_seq; Type: SEQUENCE; Schema: public; Owner: 1702admin
--

CREATE SEQUENCE public.submissions_submission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submissions_submission_id_seq OWNER TO "1702admin";

--
-- Name: submissions_submission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: 1702admin
--

ALTER SEQUENCE public.submissions_submission_id_seq OWNED BY public.submissions.submission_id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: 1702admin
--

CREATE TABLE public.tasks (
    task_id integer NOT NULL,
    task_name character varying(200) NOT NULL,
    task_description text,
    test_cases json NOT NULL,
    hidden_test_cases json,
    memory_limit integer NOT NULL,
    time_limit integer NOT NULL,
    is_active boolean
);


ALTER TABLE public.tasks OWNER TO "1702admin";

--
-- Name: tasks_task_id_seq; Type: SEQUENCE; Schema: public; Owner: 1702admin
--

CREATE SEQUENCE public.tasks_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_task_id_seq OWNER TO "1702admin";

--
-- Name: tasks_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: 1702admin
--

ALTER SEQUENCE public.tasks_task_id_seq OWNED BY public.tasks.task_id;


--
-- Name: usrs; Type: TABLE; Schema: public; Owner: 1702admin
--

CREATE TABLE public.usrs (
    user_id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30),
    password_hash text NOT NULL,
    user_role public.usertype NOT NULL,
    reg_date timestamp with time zone NOT NULL
);


ALTER TABLE public.usrs OWNER TO "1702admin";

--
-- Name: usrs_user_id_seq; Type: SEQUENCE; Schema: public; Owner: 1702admin
--

CREATE SEQUENCE public.usrs_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usrs_user_id_seq OWNER TO "1702admin";

--
-- Name: usrs_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: 1702admin
--

ALTER SEQUENCE public.usrs_user_id_seq OWNED BY public.usrs.user_id;


--
-- Name: submission_review id; Type: DEFAULT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submission_review ALTER COLUMN id SET DEFAULT nextval('public.submission_review_id_seq'::regclass);


--
-- Name: submissions submission_id; Type: DEFAULT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submissions ALTER COLUMN submission_id SET DEFAULT nextval('public.submissions_submission_id_seq'::regclass);


--
-- Name: tasks task_id; Type: DEFAULT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.tasks ALTER COLUMN task_id SET DEFAULT nextval('public.tasks_task_id_seq'::regclass);


--
-- Name: usrs user_id; Type: DEFAULT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.usrs ALTER COLUMN user_id SET DEFAULT nextval('public.usrs_user_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: 1702admin
--

COPY public.alembic_version (version_num) FROM stdin;
ee6f208e42d1
\.


--
-- Data for Name: submission_review; Type: TABLE DATA; Schema: public; Owner: 1702admin
--

COPY public.submission_review (id, submission_id, teacher_id, reviewed_at, comment) FROM stdin;
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: 1702admin
--

COPY public.submissions (submission_id, user_id, task_id, code, status, passed_tests, total_tests, error_message, comment, submitted_at, celery_task_id) FROM stdin;
15	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-10 19:30:27.862145+00	8eaa1775-4178-499d-87a5-bba63ac2bc02
25	3	1	#include <stdio.h>\n\nint main() {\n    printf("\\nHello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-12 09:24:07.003066+00	0c4dbc66-9f63-4932-bdfd-47e79d177550
16	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-10 19:44:45.520705+00	0354f1f5-0545-4244-9231-254cceb34c2d
17	2	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-10 19:45:13.317668+00	0d24afe1-fa66-4955-89f8-88aa82e5deef
32	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:34:27.793574+00	77c38219-e6d1-4491-8d5b-e3ff61bf1da2
18	3	1	#include <stdio.h>\n\nint main() {\n    printf("\\nHello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-10 20:21:29.753514+00	a186bd5c-a669-4f19-868c-b0eedb1b003e
26	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:10:47.364367+00	74c55000-8cfc-490c-a288-e422b488eeda
19	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!")\n    return 0;\n}	COMPILATION_ERROR	0	1	/uploads/3412b0f79c584b51aa53c54660acc0cf/solution.c: In function 'main':\n/uploads/3412b0f79c584b51aa53c54660acc0cf/solution.c:4:28: error: expected ';' before 'return'\n    4 |     printf("Hello, World!")\n      |                            ^\n      |                            ;\n    5 |     return 0;\n      |     ~~~~~~                  \n	\N	2026-07-10 20:21:37.353796+00	c54cc7a9-b654-4c1b-b0d1-9f146577cf5d
20	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!")\n    return 0;\n}	COMPILATION_ERROR	0	1	sh: can't open '/uploads/41cff8c80a7c48f3bcc66e40db94ef06/s.sh': No such file or directory\n	\N	2026-07-12 07:51:36.649784+00	b3118d6e-e4ca-4751-b896-d05ed88589c3
21	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	COMPILATION_ERROR	0	1	sh: can't open '/uploads/a85d980a38894423b41d795173da05d7/s.sh': No such file or directory\n	\N	2026-07-12 07:52:33.225206+00	9b2df460-09db-4040-b1a3-14657e4f4f54
27	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:10:53.530981+00	ddade4f2-c020-4958-be79-3969cc86704a
22	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	COMPILATION_ERROR	0	1	sh: can't open '/uploads/9b5e65d870c8401e81fb06203660b1ad/s.sh': No such file or directory\n	\N	2026-07-12 07:52:47.03592+00	224afca5-c821-4196-ac1c-18002b4cf235
23	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-12 08:13:59.496895+00	ed9df8b4-d36d-4d46-94b3-bd887979c94d
24	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!")\n    return 0;\n}	COMPILATION_ERROR	0	1	solution.c: In function 'main':\nsolution.c:4:28: error: expected ';' before 'return'\n    4 |     printf("Hello, World!")\n      |                            ^\n      |                            ;\n    5 |     return 0;\n      |     ~~~~~~                  \n	\N	2026-07-12 08:14:09.752019+00	68d74e0a-3e35-422c-ac7e-521e8e6e72a2
28	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:10:59.664558+00	9400ab4d-1699-48fb-ad2f-965952328d65
33	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:34:35.246927+00	d1697d40-5e5d-4c9f-a9a2-56ab947403b0
29	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:11:07.610589+00	48e44e6a-808b-4343-a641-5aec42b5d650
30	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:11:14.420665+00	2e76aff5-b244-45f9-af46-f3c4374a8592
31	3	1	#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}	OK	1	1		\N	2026-07-19 21:34:18.226884+00	1d6fb5d8-c6ff-4fa6-99aa-7857fa20d2c1
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: 1702admin
--

COPY public.tasks (task_id, task_name, task_description, test_cases, hidden_test_cases, memory_limit, time_limit, is_active) FROM stdin;
1	Hello, World!	Write a program that prints the following text exactly:\r\n\r\nHello, World!\r\n\r\nNo input is provided.	[{"input": "", "output": "Hello, World!\\n"}]	null	128	1	t
\.


--
-- Data for Name: usrs; Type: TABLE DATA; Schema: public; Owner: 1702admin
--

COPY public.usrs (user_id, username, first_name, last_name, password_hash, user_role, reg_date) FROM stdin;
2	rod1	rodion		scrypt:32768:8:1$mAsDXsJFQXccXh4w$b98e804b4538f711100c5e16eadde5cbcbe7618e37b7d3b363e272a5d269c4fc38e079c1ce9910ddf55bab3356e36d9e4cfcdaaea708586e71b3df84ed2eddd7	STUDENT	2026-07-10 19:18:40.944958+00
3	rodos	rodion		scrypt:32768:8:1$hZypJBcT8Pk3cna8$89523c2cdfb1b4b2c5e27df20bd96f0a7ea383f84769ffe396807ab10e0645f3fdb3223f93a77ae04a5911e13fcbe6cd3dcd2b7ddb79e8908fd9f58f06f4a3b9	ADMIN	2026-07-10 19:30:20.751405+00
\.


--
-- Name: submission_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: 1702admin
--

SELECT pg_catalog.setval('public.submission_review_id_seq', 1, false);


--
-- Name: submissions_submission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: 1702admin
--

SELECT pg_catalog.setval('public.submissions_submission_id_seq', 33, true);


--
-- Name: tasks_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: 1702admin
--

SELECT pg_catalog.setval('public.tasks_task_id_seq', 1, true);


--
-- Name: usrs_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: 1702admin
--

SELECT pg_catalog.setval('public.usrs_user_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: submission_review submission_review_pkey; Type: CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submission_review
    ADD CONSTRAINT submission_review_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (submission_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (task_id);


--
-- Name: tasks tasks_task_name_key; Type: CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_task_name_key UNIQUE (task_name);


--
-- Name: usrs usrs_pkey; Type: CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.usrs
    ADD CONSTRAINT usrs_pkey PRIMARY KEY (user_id);


--
-- Name: usrs usrs_username_key; Type: CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.usrs
    ADD CONSTRAINT usrs_username_key UNIQUE (username);


--
-- Name: submission_review submission_review_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submission_review
    ADD CONSTRAINT submission_review_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.submissions(submission_id);


--
-- Name: submission_review submission_review_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submission_review
    ADD CONSTRAINT submission_review_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.usrs(user_id);


--
-- Name: submissions submissions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: submissions submissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: 1702admin
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.usrs(user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict oUvultnCINWsODgECJlEeQvWHihJpikaKp9Idez8jmSaZptFj580ro3rXYb7TsF

